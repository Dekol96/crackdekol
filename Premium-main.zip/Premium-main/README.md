# Premium

Script Crack Instagram !

# Cara Menggunakan
Link : https://youtu.be/u17ZQgSs3aY

# Screenshot
![Screenshot_2021-12-24-08-46-44-83_84d3000e3f4017145260f7618db1d683](https://user-images.githubusercontent.com/65714340/147317458-cb647309-e2dd-4f76-a822-181a3cccc823.png)

# Perintah
    • pkg update && upgrade
    • pkg install git
    • pkg install python2
    • pip2 install requests
    • pip2 install futures
    • git clone https://github.com/RozhakXD/Premium
    • cd Premium
    • python2 Prem.py
# Sosial Media
    • Fb : https://free.facebook.com/rozhak.xyz
    • Ig : https://www.instagram.com/rozhak_official
    • Yt : https://www.youtube.com/rozhakid
    • Wa : https://wa.me/6283847921480
